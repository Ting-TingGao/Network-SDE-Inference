function [fig, fig2, PlotData] = Fig1PlotFun(TrueFileDir,InferFileDirList,boundary)
    TrueFile =  readmatrix(TrueFileDir, 'OutputType', 'string');
    TrueData = str2double(TrueFile(2:end,2:end));
    TrueFuncNam = TrueFile(2:end,1);

    PlotData = zeros(size(TrueData,1),length(InferFileDirList)+1);
    PlotData(:,1) = TrueData;
    for ii = 1:length(TrueFuncNam)
        for jj = 1:length(InferFileDirList)
            InferFile = readmatrix(InferFileDirList{jj}, 'OutputType', 'string');
            InferData = str2double(InferFile(2:end,2:end));
            InferFuncNam = InferFile(2:end,1);
            PlotData(ii,jj+1) =mean(InferData( find(InferFuncNam==TrueFuncNam(ii)),:));
        end
    end
    
    
    figure
    bar( PlotData)
    set(gca,'xticklabel',TrueFuncNam)
    fig = gca;
    
    RelatedError =  (PlotData(:,2:end)-PlotData(:,1))./PlotData(:,1);
    figure
    imagesc(linspace(1,length(TrueFuncNam),length(TrueFuncNam)),linspace(1,length(InferFileDirList),length(InferFileDirList)),RelatedError')
    set(gca,'xtick',linspace(1,length(TrueFuncNam),length(TrueFuncNam)),'xticklabel',TrueFuncNam)
    set(gca,'ytick',linspace(1,length(InferFileDirList),length(InferFileDirList)),'yticklabel',{'ER','SF','Real'})
    axis equal
    hold on
    for jj = 1:length(InferFileDirList)
        plot([0,length(TrueFuncNam)+1],[0.5+jj,0.5+jj],'k')
    end
    for jj = 1:length(TrueFuncNam)
        plot([0.5+jj,0.5+jj],[0,length(InferFileDirList)+1],'k')
    end
    %%
    pixel = 256;
    colorbarmat = zeros(pixel,3);
    colorbarmat(1:pixel/2,1) = linspace(0,1,pixel/2);colorbarmat(pixel/2+1:end,1) = linspace(1,0,pixel/2);
    colorbarmat(1:pixel/2,2) = linspace(0,1,pixel/2);colorbarmat(pixel/2+1:end,2) = linspace(1,0,pixel/2);
    colorbarmat(1:pixel/2,3) = linspace(0,1,pixel/2);colorbarmat(pixel/2+1:end,3) = linspace(1,1,pixel/2);
    %%
    colormap(colorbarmat)
    colorbar
    caxis([-boundary,boundary])
    fig2 = gca
end

