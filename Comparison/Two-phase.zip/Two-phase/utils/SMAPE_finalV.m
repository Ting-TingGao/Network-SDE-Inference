clc, clf, clear, close all
tic
number_files = 10;
SMAPE = zeros(number_files,2);
per = zeros(number_files,1);
count = 0;
for i=1:number_files
    coef = csvread(['INferred_KuramotoSigma_0' num2str(i) '.csv']);
    coef = coef(2:size(coef,1),:);
    for ii = 1:length(coef)-1
        for ij = 1: size(coef,1)
            if coef(ij,1) ~= 0 && coef(ij,ii) ~=0
                count = count+1;
            end
        end
    end
    terms_num = size(coef,1);
    real_terms = sum(coef(:,1)~=0);
    coef_ = coef(:,2:size(coef,2));
    infer_num = size(coef_,2);
    error = zeros(infer_num,1);
    for j = 1:infer_num
        count = 0;
        tmp = 0;
        for jj = 1:terms_num
            if coef_(jj,j) == 0 && coef(jj,1) == 0
                count = count + 1;
                tmp = tmp+0;
            else
            tmp = tmp + abs(coef_(jj,j)-coef(jj,1))/(abs(coef_(jj,j))+abs(coef(jj,1)));
            end
        end
        error(j) = tmp/(terms_num-count);
    end
    Error=error';
    Mean_error = mean(Error);
     SMAPE(1) = mean(error);
     SMAPE(2) = std(error,0);
     per(i) = (length(coef)-1-count)/length(coef);
end
coef_ = mean(coef_,2);
for iii = 1:terms_num
    error1(iii) = (coef_(iii)-coef(iii,1))/abs(coef(iii,1));
end