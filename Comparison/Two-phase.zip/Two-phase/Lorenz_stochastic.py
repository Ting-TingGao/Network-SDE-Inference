
import pandas as pd
import numpy as np
import sys
import matplotlib.pyplot as plt
sys.path.append("/Users/lana_g/Desktop/Code_ocean")
from utils.ElementaryFunctionsPool import *
from utils.ElementaryFunctions_Matrix import *
from utils.NumericalDerivatives import *
from TwoPhaseInference import *

"""Import time series data and adjacency matrix"""
A = pd.read_csv('/Users/lana_g/Downloads/comparison 2/Lorenz2nodesAdj.csv',encoding='utf-8',header=None)
A = A.values

data = pd.read_csv('/Users/lana_g/Downloads/comparison 2/Lorenz_x_stochastic_gamma075.csv',encoding='utf-8',header=None)
data = data.values
Dim = 3
Nnodes = 20
deltT = 0.01


selfPolyOrder = 3


plotstart = 0.5
plotend = 0.9
Keep = 10
SampleTimes = 20
Batchsize = 10

NumDiv = NumericalDeriv(data,Dim,Nnodes,deltT)
data = data[2:-2,:]

Matrix = ElementaryFunctions_Matrix(data, Dim, Nnodes, A, selfPolyOrder, coupledPolyOrder = 1, PolynomialIndex = True, TrigonometricIndex = False, \
        ExponentialIndex = True, FractionalIndex = False, ActivationIndex = False, RescalingIndex = False, CoupledPolynomialIndex = True, \
            CoupledTrigonometricIndex = True, CoupledExponentialIndex = False, CoupledFractionalIndex = False, \
                CoupledActivationIndex = False, CoupledRescalingIndex = False)

Matrix = Matrix.replace([np.inf, -np.inf], np.nan).dropna(axis=1)
Lambda = pd.read_csv('/Users/lana_g/Desktop/Code_ocean/data/Threshold/Lambda_Lorenz.csv',encoding='utf-8',header=None)

print('Two-phase inference approach started.')
import time
Start = time.time()
"""Inference approach"""
fig = plt.figure(figsize=(16, 9))
for dim in range(Dim):
    locals()['InferredResults'+str(dim+1)], locals()['phase_one_series'+str(dim+1)], \
        locals()['wAIC'+str(dim+1)], locals()['withConstant'+str(dim+1)] = \
            TwoPhaseInference(Matrix, NumDiv, Nnodes, dim, Dim, Keep, SampleTimes, Batchsize, Lambda, plotstart, plotend)
    
    equalZero = (locals()['InferredResults'+str(dim+1)]==0).sum(axis=1)
    for z in range(0,locals()['InferredResults'+str(dim+1)].shape[0]):
        if equalZero[z] >=SampleTimes*0.7:
            locals()['InferredResults'+str(dim+1)].iloc[z,:] = np.nan
    locals()['InferredResults'+str(dim+1)] = locals()['InferredResults'+str(dim+1)].dropna(axis=0,how='all')
    print(locals()['InferredResults'+str(dim+1)])
    locals()['InferredResults'+str(dim+1)].to_csv('/Users/lana_g/Desktop/Code_ocean/InferredFunctions_Coefficients/'+'InferredLorenzEqu_of_'+str(dim+1)+'-dimension_gamma075.csv', index=True, header=True)

    """visualization"""
    ax1 = fig.add_subplot(Dim,2,dim*2+1)
    plt.title("Phase 1 result for dimension-%d" % (dim + 1),fontsize=10)
    plt.subplots_adjust(left=None, bottom=None, right=None, top=None, wspace=None, hspace=0.5)
    plt.xticks([])
    plt.yticks([])
    phaseOne_result = locals()['phase_one_series'+str(dim+1)]
    x_cor = range(len(phaseOne_result.values[:,0])) 
    for i in range(len(phaseOne_result.values[0,:])):
        ax1.plot(x_cor,phaseOne_result.values[:,i])

    ax2 = fig.add_subplot(Dim,2,dim*2+2)
    plt.title("Model complexity of dimension-%d" % (dim + 1),fontsize=10)
    plt.subplots_adjust(left=None, bottom=None, right=None, top=None, wspace=None, hspace=0.5)
    Index = np.arange(1,Keep,1)
    index_str = ['10','9','8','7','6','5','4','3','2']
    plt.xticks(fontsize=10)
    plt.xticks(Index,index_str)
    plt.xlabel('Model complexity',fontsize=10)
    plt.ylabel('wAIC',fontsize=10)  
    AIC_curve = locals()['wAIC'+str(dim+1)]
    if locals()['withConstant'+str(dim+1)] == True:
        AIC_curve = np.delete(AIC_curve, 1, axis=0)
    else:
        AIC_curve = np.delete(AIC_curve, 0, axis=0)
    for i in range(0,SampleTimes):
        ax2.plot(Index,AIC_curve[:,i], marker='o')

plt.show()
End = time.time()
print('Time comsuming:', End-Start)
