from .fastgl import glpair
