.. role:: hidden
    :class: hidden-section

:github_url: https://github.com/coursekevin/svise

PCA 
=================================
This section contains some utilties for
performing PCA in PyTorch. It is mostly 
a PyTorch clone of the sklearn implementation 
with some useful features for our workflow.

:hidden:`PCA`
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: svise.pca.PCA
    :members:
